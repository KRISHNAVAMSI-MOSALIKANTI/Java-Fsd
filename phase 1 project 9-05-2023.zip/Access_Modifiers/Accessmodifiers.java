package Access_Modifiers;

public class Accessmodifiers {

	public static void main(String[] args) 
	{
		MyClass myClass = new MyClass();
		myClass.publicMethod();
		myClass.protectedMethod();
		myClass.defaultMethod();
		}
		}
		class MyClass {
		public int publicField = 10;
		protected int protectedField = 20;
		int defaultField = 30;
		private int privateField = 40;
		public void publicMethod()
		{
		System.out.println("This is a public method");
		}
		protected void protectedMethod()
		{
		System.out.println("This is a protected method");
		}
		void defaultMethod()
		{
		System.out.println("This is a default method");
		}
		private void privateMethod()
		{
		System.out.println("This is a private method");
		}
		}